import subprocess
from pathlib import Path
import platform  # <-- Add this import
import toml

# --------------- User inputs ---------------
project_name = input("Enter your project name: ").strip()
if not project_name:
    project_name = "agent"

dir_type = input("Do you want to add a /src directory? (Y/n): ").lower()
uv_command = f"uv init {project_name}"
if dir_type in ("y", "yes", ""):
    uv_command = f"uv init --package {project_name}"

# --------------- Initialize UV project ---------------
subprocess.run(uv_command, shell=True, check=True)

# Define the project path and venv path
project_path = Path.cwd() / project_name
venv_path = project_path / "venv"

# Create virtual environment inside the project
subprocess.run(f"uv venv", shell=True, check=True)

# Cross-platform venv activation and install openai-agents
is_windows = platform.system() == "Windows"
if is_windows:
    activate_cmd = f"{venv_path}\\Scripts\\activate"
    install_cmd = f"{activate_cmd} && uv add openai-agents"
    subprocess.run(install_cmd, shell=True, check=True)
else:
    activate_cmd = f"source {venv_path}/bin/activate"
    install_cmd = f"{activate_cmd} && uv add openai-agents"
    subprocess.run(install_cmd, shell=True, executable="/bin/bash", check=True)

# --------------- Gemini agent inputs ---------------
gemini_api_key = input("Enter Gemini API key: ")

default_models = ["gemini-2.0-flash", "gemini-2.5-flash"]
print("Choose a Gemini model or type your own:")
for i, m in enumerate(default_models, 1):
    print(f"{i}. {m}")
model_input = input("Enter the number of the model or type your own: ")

# Determine the actual model
if model_input in ["1", "2"]:
    model = default_models[int(model_input) - 1]
else:
    model = model_input

agent_name = input("Enter agent name (default: Helpful Assistant): ")
if not agent_name.strip():
    agent_name = "Helpful Assistant"

agent_purpose = input("Enter your agent work (default: You're a helpful assistant, help user with any query): ")
if not agent_purpose.strip():
    agent_purpose = "You're a helpful assistant, help user with any query"
    
env_file = project_path / ".env"
env_file.write_text(f"GEMINI_API_KEY={gemini_api_key}\nGEMINI_MODEL={model}\n")

print("Agent Name:", agent_name)
print("Agent Purpose:", agent_purpose)

# --------------- Create agent folder and main.py ---------------
agent_folder = project_path / "agent"
agent_folder.mkdir(exist_ok=True)

main_file = agent_folder / "main.py"
if not main_file.exists():
    main_file.write_text(f"""import os
from dotenv import load_dotenv

def main():
    load_dotenv()
    api_key = os.getenv("GEMINI_API_KEY")
    model = os.getenv("GEMINI_MODEL")
    
    print("Agent Name: {agent_name}")
    print("Agent Purpose: {agent_purpose}")
    print("Using Gemini Model: {model}")
    # Add your agent logic here

if __name__ == '__main__':
    main()
""")

# --------------- Update pyproject.toml with UV script ---------------
# Convert agent_name to a valid script name (no spaces, lowercase)
script_name = agent_name.strip().lower().replace(" ", "-")
if not script_name:
    script_name = "helpful-assistant"

pyproject_file = project_path / "pyproject.toml"
if pyproject_file.exists():
    pyproject_data = toml.load(pyproject_file)
else:
    pyproject_data = {}

pyproject_data.setdefault("tool", {}).setdefault("uv", {}).setdefault("scripts", {})
pyproject_data["tool"]["uv"]["scripts"][script_name] = "agent.main:main"

with pyproject_file.open("w") as f:
    toml.dump(pyproject_data, f)

print(f"\n✅ pyproject.toml updated with script '{script_name}'.")
print(f"\n🎉 You can now run your agent with:")
print(f"   uv run {script_name}")
