import subprocess
from pathlib import Path
import sys
import re

# toml may not be available in some environments, give helpful message
try:
    import toml
except Exception as e:
    print("ERROR: python 'toml' package is required by the generator. Install it with:")
    print("  pip install toml")
    raise

try:
    from InquirerPy import inquirer
except Exception:
    print("ERROR: InquirerPy is required. Install it with:")
    print("  pip install InquirerPy")
    raise


def sanitize(name: str) -> str:
    """Make a safe script name: lower, replace spaces and invalid chars with '-'"""
    s = (name or "").strip().lower()
    # replace any run of non-alnum with dash
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = s.strip("-")
    return s or "helpful-assistant"


def run_cmd(cmd, cwd=None, shell=False):
    """Run subprocess and raise a helpful error if it fails."""
    try:
        subprocess.run(cmd, cwd=cwd, shell=shell, check=True)
    except subprocess.CalledProcessError as e:
        print(f"\nERROR: Command failed: {cmd}")
        print(f"Return code: {e.returncode}")
        if cwd:
            print(f"Working dir: {cwd}")
        print("Make sure `uv` is installed and available in PATH (pip install uv).")
        raise


def main():
    # --------------- User inputs ---------------
    project_name = inquirer.text(message="Enter your project name:", default="agent").execute()

    dir_type = inquirer.confirm(
        message="Do you want to add a /src directory?", default=True
    ).execute()

    if dir_type:
        uv_command = f"uv init --package {project_name}"
    else:
        uv_command = f"uv init {project_name}"

    # --------------- Initialize UV project ---------------
    print(f"\nRunning: {uv_command}")
    run_cmd(uv_command, shell=True)

    # Define the project path
    project_path = Path.cwd() / project_name
    if not project_path.exists():
        print(f"ERROR: project folder not found at {project_path} after uv init.")
        return

    # --------------- Create virtual environment inside the project ---------------
    print("\nCreating virtual environment with `uv venv`...")
    run_cmd("uv venv", cwd=project_path, shell=True)

    # --------------- Install required runtime packages into project venv via uv ---------------
    print("\nInstalling runtime packages (openai-agents, python-dotenv) into the project with `uv add`...")
    run_cmd(["uv", "add", "openai-agents", "python-dotenv"], cwd=project_path)

    # --------------- Gemini agent inputs ---------------
    gemini_api_key = inquirer.secret(message="Enter Gemini API key:").execute()

    default_models = ["gemini-2.0-flash", "gemini-2.5-flash", "Custom (type your own)"]
    model_choice = inquirer.select(message="Choose a Gemini model:", choices=default_models).execute()

    if model_choice == "Custom (type your own)":
        model = inquirer.text(message="Enter your Gemini model:").execute().strip() or default_models[0]
    else:
        model = model_choice

    agent_name = inquirer.text(message="Enter agent name:", default="Helpful Assistant").execute()
    agent_purpose = inquirer.text(
        message="Enter your agent work:",
        default="You're a helpful assistant, help user with any query",
    ).execute()

    # --------------- Write .env ---------------
    env_file = project_path / ".env"
    env_file.write_text(f"GEMINI_API_KEY={gemini_api_key}\nGEMINI_MODEL={model}\n", encoding="utf-8")
    print(f"\n✅ .env written to {env_file}")

    print("\nAgent Name:", agent_name)
    print("Agent Purpose:", agent_purpose)

    # --------------- Create agent folder and files ---------------
    agent_folder = project_path / "agent"
    agent_folder.mkdir(parents=True, exist_ok=True)

    # ensure package initializer so imports like `agent.main` always work
    init_py = agent_folder / "__init__.py"
    if not init_py.exists():
        init_py.write_text("# package initializer for agent\n", encoding="utf-8")

    # write agent main
    main_file = agent_folder / "main.py"
    if not main_file.exists():
        main_file.write_text(
            f"""import os
from dotenv import load_dotenv

def main():
    load_dotenv()
    api_key = os.getenv("GEMINI_API_KEY")
    model = os.getenv("GEMINI_MODEL")

    print("Agent Name: {agent_name}")
    print("Agent Purpose: {agent_purpose}")
    print(f"Using Gemini Model: {{model}}")
    # Add your agent logic here

if __name__ == '__main__':
    main()
""",
            encoding="utf-8",
        )
        print(f"\n✅ Created {main_file}")

    # --------------- Update pyproject.toml with UV script (friendly + unique) ---------------
    script_friendly = sanitize(agent_name)
    script_unique = f"{sanitize(project_name)}-{script_friendly}"

    pyproject_file = project_path / "pyproject.toml"
    if pyproject_file.exists():
        pyproject_data = toml.load(pyproject_file)
    else:
        pyproject_data = {}

    pyproject_data.setdefault("tool", {}).setdefault("uv", {}).setdefault("scripts", {})
    # add friendly and unique aliases (unique avoids collisions)
    pyproject_data["tool"]["uv"]["scripts"][script_friendly] = "agent.main:main"
    pyproject_data["tool"]["uv"]["scripts"][script_unique] = "agent.main:main"

    with pyproject_file.open("w", encoding="utf-8") as f:
        toml.dump(pyproject_data, f)

    print(f"\n✅ pyproject.toml updated with scripts: '{script_friendly}' and '{script_unique}'.")
    print("\n🎉 Next steps:")
    print(f"  cd {project_path}")
    print(f"  uv run {script_unique}   # recommended (unique, avoids collision)")
    print(f"or\n  uv run {script_friendly}   # friendly name (works when in project folder)")

if __name__ == "__main__":
    main()